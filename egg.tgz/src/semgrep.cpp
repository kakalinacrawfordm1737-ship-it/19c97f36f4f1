// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("semgrep"); }
int main(){
  announce();
  return lionss_run_workload("semgrep");
}
