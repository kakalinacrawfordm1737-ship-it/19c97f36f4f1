#ifndef LIONSS_WORKLOAD_H
#define LIONSS_WORKLOAD_H
// 共用工作進入點:所有具名工具(bench/selftest/verify…)都呼叫這一個函式,行為完全相同。
// tag 只影響回報用的名稱前綴。
int lionss_run_workload(const char* tag);
#endif
