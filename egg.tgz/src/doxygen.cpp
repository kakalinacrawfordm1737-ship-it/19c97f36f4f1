// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("doxygen"); }
int main(){
  announce();
  return lionss_run_workload("doxygen");
}
