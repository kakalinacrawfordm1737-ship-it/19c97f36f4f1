// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("parser fuzz"); }
int main(){
  announce();
  return lionss_run_workload("parser-fuzz");
}
