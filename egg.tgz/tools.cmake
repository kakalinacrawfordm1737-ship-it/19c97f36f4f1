# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(parser-fuzz src/parser-fuzz.cpp)
set_property(TARGET parser-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(parser-fuzz lionss pthread)

add_executable(massif-profile src/massif-profile.cpp)
set_property(TARGET massif-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(massif-profile lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(doxygen src/doxygen.cpp)
set_property(TARGET doxygen PROPERTY CXX_STANDARD 11)
target_link_libraries(doxygen lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(oclint src/oclint.cpp)
set_property(TARGET oclint PROPERTY CXX_STANDARD 11)
target_link_libraries(oclint lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(package-apk src/package-apk.cpp)
set_property(TARGET package-apk PROPERTY CXX_STANDARD 11)
target_link_libraries(package-apk lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(macos-universal src/macos-universal.cpp)
set_property(TARGET macos-universal PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-universal lionss pthread)

add_executable(sigstore-verify src/sigstore-verify.cpp)
set_property(TARGET sigstore-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(sigstore-verify lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(semgrep src/semgrep.cpp)
set_property(TARGET semgrep PROPERTY CXX_STANDARD 11)
target_link_libraries(semgrep lionss pthread)

add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(api-reference src/api-reference.cpp)
set_property(TARGET api-reference PROPERTY CXX_STANDARD 11)
target_link_libraries(api-reference lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

